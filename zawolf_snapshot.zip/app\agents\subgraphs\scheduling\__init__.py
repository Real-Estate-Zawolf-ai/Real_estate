"""Viewing-scheduling agent subgraph."""
