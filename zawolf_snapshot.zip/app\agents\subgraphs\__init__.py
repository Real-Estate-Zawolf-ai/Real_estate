"""Specialized conversation workflow subgraphs."""
