"""Sales-conversation agent subgraph."""
