"""Retrieval-augmented generation components."""
