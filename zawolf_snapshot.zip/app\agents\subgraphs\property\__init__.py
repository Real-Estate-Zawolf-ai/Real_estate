"""Property-search agent subgraph."""
